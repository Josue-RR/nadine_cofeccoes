<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login - Sistema RNC</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/login.css">
</head>
<style>

    #menu{
        overflow: auto;
    }

</style>
<body>
    <div class="login-container">
        <h2>Acesso ao Sistema</h2>
        <form id="loginForm">
            <div class="form-group">
                <label for="username">Usuário:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>
            </div>
            <button type="submit">Entrar</button>
            <div id="mensagemErro" class="error"></div>
        </form>
    </div>

    <script>
document.addEventListener('DOMContentLoaded', function() {
    const user = JSON.parse(localStorage.getItem('usuario'));

    if (user && user.permissoes && user.permissoes.operador) {
        const menu = document.querySelector('#menu .links');

        // Criar os links extras para operador
        const linksExtra = `
            <a href="usuarios.html">👥 Cadastro de Usuários</a>
            <a href="setores.html">🏢 Cadastro de Setores</a>
            <a href="cadastrar-clientes.html">🏭 Cadastro de Clientes</a>
            <a href="status.html">📌 Cadastro de Status</a>
            <a href="tipos-nc.html">📋 Cadastro de Tipos NC</a>
            <a href="produtos.html">📦 Cadastro de Produtos</a>
            <a href="colaboradores.html">👤 Cadastro de Colaboradores</a>
        `;
        menu.insertAdjacentHTML('beforeend', linksExtra);
    }
});
</script>
</body>

<script src="../js/login.js"></script>
</html>
