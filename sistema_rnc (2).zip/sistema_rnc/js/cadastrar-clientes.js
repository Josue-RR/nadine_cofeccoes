
function loadShow(){
    const loading = document.getElementById('loading-screen');
    loading.style.display = "flex"
}

function loadHide() {
    const loading = document.getElementById('loading-screen');
    loading.style.display = 'none';
}

loadHide();

document.getElementById('form-cadastro-cliente').addEventListener('submit', function(e){
    e.preventDefault();


    loadShow();

    const formData = {
        nome: document.getElementById('nome').value,
        cnpj: document.getElementById('cnpj').value,
        email: document.getElementById('email').value,
        telefone: document.getElementById('telefone').value
    }

    fetch('http://localhost/sistema_rnc/controllers/cadastrar-clientes.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(reponse => {
        if (!reponse.ok) {
            throw new Error('Erro na requisição');
        }
        return reponse.json();
    })
    .then(data => {
        if (data.success) {
            document.getElementById('mensagem').innerHTML = '<p class="success" >Cliente cadastrado com sucesso</p>';
            document.getElementById('form-cadastro-cliente').reset()
        } else {
            throw new Error(data.error || 'Erro ao cadastrar cliente')
        }
    })
    .catch(error => {
        document.getElementById('mensagem').innerHTML = `<p class="error" >Erro: ${error.message}</p>`;

    })
    .finally(() => {
        loadHide();
    })
})