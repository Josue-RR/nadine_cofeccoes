document.getElementById('loginForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const senha = document.getElementById('senha').value;

    try {
        await fazerLogin(username, senha);
        window.location.href = 'dashbord.html';
    } catch (error) {
        document.getElementById('mensagemErro').textContent = error.message;
    }
});



async function fazerLogin(username, senha) {
    try {
        const reponse = await fetch('/sistema_rnc/controllers/login.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, senha})
        });

        const data = await reponse.json();

        console.log(data);

        if (!data.success) {
            throw new Error(data.error || 'Erro ao fazer o login');
        }

        localStorage.setItem('usuario', JSON.stringify(data.usuario));

        return data.usuario;
    } catch (error) {
        console.error('Erro no Login: ', error);
        throw error;
    }
}


function verificaUserLogado(){
    return localStorage.getItem('usuario') !== null;
}

function getUser() {
    const usuario = localStorage.getItem('usuario');
    return usuario ? JSON.parse(usuario) : null
}