function loadHide() {
    const loading = document.getElementById('loading-screen');
    loading.style.display = 'none';
}

function loadShow(){
    const loading = document.getElementById('loading-screen');
    loading.style.display = "flex"
}

document.addEventListener('DOMContentLoaded', function () {
    loadShow();
 
    listarClientes();
})


async function listarClientes() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/listar-clientes.php');
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            throw new Error(`Resposta não é JSON: ${text}`);
        }

        const data = await response.json();
        const tabela = document.getElementById("tabela");
        tabela.innerHTML = ''; // Limpa a tabela

        if (!Array.isArray(data)) {
            throw new Error('Dados recebidos não são um array');
        }

        if (data.length === 0) {
            tabela.innerHTML = '<tr><td colspan="5">Nenhum cliente cadastrado</td></tr>';
            return;
        }

        data.forEach(cliente => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${cliente.id || ''}</td>
                <td>${cliente.nome || ''}</td>
                <td>${cliente.cnpj || ''}</td>
                <td>${cliente.email || ''}</td>
                <td>${cliente.telefone || ''}</td>
            `;
            tabela.appendChild(row);
        });

    } catch (error) {
        console.error('Erro ao carregar clientes:', error);
        document.getElementById("tabela").innerHTML = `
            <tr>
                <td colspan="5" class="error">Erro ao carregar dados: ${error.message}</td>
            </tr>
        `;
    } finally{
        loadHide();
    }
}