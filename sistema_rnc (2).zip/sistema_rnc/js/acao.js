document.addEventListener('DOMContentLoaded', function () {
    carregarRNCs();
    listarAcoes();
    buscaColaborador();

    document.getElementById('form-acao').addEventListener('submit', async function (e) {
        e.preventDefault();
        const dados = {
            id_rnc: document.getElementById('id_rnc').value,
            descricao: document.getElementById('descricao').value,
            data_execucao: document.getElementById('data_execucao').value,
            id_responsavel: document.getElementById('colaborador').value
        };

        try {
            const response = await fetch('http://localhost/sistema_rnc/controllers/acao.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(dados)
            });
            const result = await response.json();
            if (result.success) {
                alert('Ação registrada com sucesso!');
                listarAcoes();
                this.reset();
            } else {
                alert('Erro: ' + result.error);
            }
        } catch (error) {
            console.error(error);
        }
    });
});

async function carregarRNCs() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/rnc.php');
        const result = await response.json();
        const select = document.getElementById('id_rnc');
        result.data.forEach(rnc => {
            const option = document.createElement('option');
            option.value = rnc.rnc_id;
            option.text = `RNC #${rnc.rnc_id} - ${rnc.descricao}`;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Erro ao carregar RNCs:', error);
    }
}

async function listarAcoes() {
    buscaColaborador();
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/acao.php');
        const result = await response.json();
        const tbody = document.getElementById('tabela-acoes');
        tbody.innerHTML = '';

        result.data.forEach(acao => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${acao.id}</td>
                <td>#${acao.id_rnc}</td>
                <td><input type="text" value="${acao.descricao}" onchange="editarCampo(${acao.id}, 'descricao', this.value)"></td>
                <td><input type="date" value="${acao.data_execucao}" onchange="editarCampo(${acao.id}, 'data_execucao', this.value)"></td>
                <td><select id="colaborador" name="colaborador" required>
                    <option value="${acao.id_responsavel}">${acao.colaborador_nome}</option>
                </select></td>
                
                <td><button onclick="excluirAcao(${acao.id})">Excluir</button></td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Erro ao listar ações:', error);
    }
}

async function editarCampo(id, campo, valor) {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/acao.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, campo, valor })
        });
        const result = await response.json();
        if (!result.success) {
            alert('Erro ao editar: ' + result.error);
        }
    } catch (error) {
        console.error('Erro ao editar:', error);
    }
}

async function excluirAcao(id) {
    if (!confirm('Tem certeza que deseja excluir esta ação?')) return;
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/acao.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        });
        const result = await response.json();
        if (result.success) {
            listarAcoes();
        } else {
            alert('Erro ao excluir: ' + result.error);
        }
    } catch (error) {
        console.error('Erro ao excluir:', error);
    }
}


async function buscaColaborador() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/colaborador.php');

        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            throw new Error(`Resposta não é JSON: ${text}`);
        }


        const data = await response.json()

        let select = document.getElementById('colaborador');

        if (!Array.isArray(data)) {
            throw new Error('Dados recebidos não são um array');
        }

        data.forEach(colaborador => {
            let option = document.createElement('option');
            option.value = colaborador.id
            option.text = colaborador.nome
            select.appendChild(option)
        });

    } catch (error) {
        console.error('Erro ao carregar colaborador:', error);
    } finally {
        console.log('deu certo ')
    }
}

