function loadHide() {
    const loading = document.getElementById('loading-screen');
    loading.style.display = 'none';
}

function loadShow(){
    const loading = document.getElementById('loading-screen');
    loading.style.display = "flex";
}

let currentRncId = null;
let statusList = [];

document.addEventListener('DOMContentLoaded', function () {
    buscaStatus();
    listarRncs();
});

document.getElementById('btn-aplicar').addEventListener('click', () => {
    listarRncs();
});

async function buscaStatus() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/status.php');
        if (!response.ok) throw new Error(`Erro HTTP: ${response.status}`);
        const data = await response.json();

        if (!Array.isArray(data)) throw new Error('Dados recebidos não são um array');

        statusList = data; // Salva globalmente para usar no modal e edição
        const select = document.getElementById('status');
        data.forEach(status => {
            let option = document.createElement('option');
            option.value = status.id;
            option.text = status.descricao;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Erro ao carregar status:', error);
    } finally {
        loadHide();
    }
}

async function listarRncs() {
    loadShow();

    try {
        const statusSelecionado = document.getElementById('status').value;
        let url = 'http://localhost/sistema_rnc/controllers/rnc.php';
        if (statusSelecionado) url += `?filtro=${statusSelecionado}`;

        const response = await fetch(url);
        if (!response.ok) throw new Error(`Erro HTTP: ${response.status}`);

        const resultado = await response.json();
        const data = resultado.data;
        const tbody = document.getElementById("tbody");
        tbody.innerHTML = '';

        if (!Array.isArray(data) || data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="10">Nenhuma RNC encontrada</td></tr>';
            return;
        }


        console.log(data)

        data.forEach(rnc => {
            const podeAlterarStatus = (rnc.status_id !== 15 && rnc.status_id !== 16); // 15 = Resolvida, 16 = Cancelada
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${rnc.rnc_id || ''}</td>
                <td>${new Date(rnc.data_abertura).toLocaleDateString() || ''}</td>
                <td>${rnc.descricao || ''}</td>
                <td>${rnc.produto_nome || ''}</td>
                <td>${rnc.setor_nome || ''}</td>
                <td>${rnc.colaborador_nome || ''}</td>
                <td>${rnc.tipo_nc_descricao || ''}</td>
                <td>${rnc.status_descricao || ''}</td>
                <td>${rnc.cliente_nome || ''}</td>
                <td>
                    <button onclick="fdetails(${rnc.rnc_id})">Detalhes</button>
                    ${podeAlterarStatus ? `
                        <button onclick="alterarStatus(${rnc.rnc_id}, 15)">Resolver</button>
                        <button onclick="alterarStatus(${rnc.rnc_id}, 16)">Cancelar</button>
                    ` : ''}
                </td>
            `;
            tbody.appendChild(row);
        });

    } catch (error) {
        console.error('Erro ao carregar rncs:', error);
        document.getElementById("tbody").innerHTML = `
            <tr>
                <td colspan="10" class="error">Erro ao carregar dados: ${error.message}</td>
            </tr>
        `;
    } finally {
        loadHide();
    }
}

async function alterarStatus(id, novoStatus) {
    if (!confirm('Confirma a alteração do status?')) return;

    try {
        loadShow();
        const response = await fetch('http://localhost/sistema_rnc/controllers/rnc.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, status: novoStatus })
        });
        const result = await response.json();

        if (result.success) {
            alert('Status alterado com sucesso!');
            listarRncs();
            // Se o modal estiver aberto com o mesmo id, atualize o status exibido
            if (currentRncId === id) {
                document.getElementById('status').textContent = statusList.find(s => s.id === novoStatus)?.descricao || '';
            }
        } else {
            alert('Erro ao alterar status: ' + result.error);
        }
    } catch (error) {
        console.error('Erro ao alterar status:', error);
    } finally {
        loadHide();
    }
}

async function fdetails(id) {
    loadShow();
    currentRncId = id;

    try {
        const response = await fetch(`http://localhost/sistema_rnc/controllers/rnc.php?id=${id}`);
        if (!response.ok) throw new Error(`Erro ao buscar detalhes: ${response.status}`);

        const resultado = await response.json();
        const rnc = resultado.data[0];

        const modalBody = document.getElementById('modal-body');
        modalBody.innerHTML = `
            <p><strong>ID:</strong> ${rnc.rnc_id}</p>
            <p><strong>Data de Abertura:</strong> <span id="data_abertura">${new Date(rnc.data_abertura).toLocaleDateString()}</span></p>
            <p><strong>Descrição:</strong> <span id="descricao">${rnc.descricao}</span></p>
            <p><strong>Status:</strong> <span id="status">${rnc.status_simplificado}</span></p>
        `;

        document.getElementById('btn-save').style.display = 'none';
        document.getElementById('modal').style.display = 'block';

    } catch (error) {
        console.error('Erro ao carregar detalhes da RNC:', error);
    } finally {
        loadHide();
    }
}

document.getElementById('btn-edit').addEventListener('click', () => {
    if (!currentRncId) return;

    const descricao = document.getElementById('descricao');
    const statusSpan = document.getElementById('status');

    descricao.innerHTML = `<input type="text" id="edit-descricao" value="${descricao.textContent}">`;

    // Cria select para status usando statusList carregada
    let selectHtml = '<select id="edit-status">';
    statusList.forEach(s => {
        const selected = s.descricao === statusSpan.textContent ? 'selected' : '';
        selectHtml += `<option value="${s.id}" ${selected}>${s.descricao}</option>`;
    });
    selectHtml += '</select>';
    statusSpan.innerHTML = selectHtml;

    document.getElementById('btn-save').style.display = 'inline-block';
});

document.getElementById('btn-save').addEventListener('click', async () => {
    if (!currentRncId) return;

    const novaDescricao = document.getElementById('edit-descricao').value;
    const novoStatus = parseInt(document.getElementById('edit-status').value);

    loadShow();
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/rnc.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'editar',
                id: currentRncId,
                descricao: novaDescricao,
                status: novoStatus
            })
        });

        const resultado = await response.json();
        if (resultado.success) {
            alert('RNC atualizada com sucesso!');
            listarRncs();
            document.getElementById('modal').style.display = 'none';
        } else {
            alert('Erro ao salvar: ' + resultado.error);
        }
    } catch (error) {
        console.error('Erro ao salvar:', error);
    } finally {
        loadHide();
    }
});

// Botão de excluir
document.getElementById('btn-delete').addEventListener('click', async () => {
    if (!currentRncId) return;
    if (!confirm('Tem certeza que deseja excluir esta RNC?')) return;

    loadShow();
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/rnc.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'excluir',
                id: currentRncId
            })
        });

        const resultado = await response.json();
        if (resultado.success) {
            alert('RNC excluída com sucesso!');
            listarRncs();
            document.getElementById('modal').style.display = 'none';
        } else {
            alert('Erro ao excluir: ' + resultado.error);
        }
    } catch (error) {
        console.error('Erro ao excluir:', error);
    } finally {
        loadHide();
    }
});

// Fechar modal
document.getElementById('close-modal').addEventListener('click', () => {
    document.getElementById('modal').style.display = 'none';
});

// Fechar ao clicar fora do modal
window.onclick = function(event) {
    const modal = document.getElementById('modal');
    if (event.target == modal) {
        modal.style.display = "none";
    }
};
