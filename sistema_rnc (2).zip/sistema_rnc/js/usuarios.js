const baseURL = '/sistema_rnc/controllers/usuario.php';

document.addEventListener('DOMContentLoaded', () => {
  verificaPermissao();
  carregarUsuarios();

  document.getElementById('formUsuario').addEventListener('submit', salvarUsuario);
});

function verificaPermissao() {
  const usuarioLogado = JSON.parse(localStorage.getItem('usuario'));
  if (!usuarioLogado || !usuarioLogado.permissoes?.operador) {
    alert('Você não tem permissão para acessar essa página!');
    window.location.href = 'dashbord.html';
  }
}

async function carregarUsuarios() {
  const tbody = document.getElementById('listaUsuarios');
  tbody.innerHTML = '<tr><td colspan="6">Carregando...</td></tr>';

  try {
    const res = await fetch(baseURL);
    const data = await res.json();

    if (!data.success) throw new Error(data.error || 'Erro ao buscar usuários');

    const usuarios = data.data;

    if (usuarios.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6">Nenhum usuário cadastrado.</td></tr>';
      return;
    }

    tbody.innerHTML = '';
    usuarios.forEach(u => {
      tbody.innerHTML += `
        <tr>
          <td>${u.id}</td>
          <td>${u.username}</td>
          <td>${u.nome_completo}</td>
          <td>${u.email}</td>
          <td>${u.permissoes.operador ? 'Sim' : 'Não'}</td>
          <td>
            <button onclick="editarUsuario(${u.id})">Editar</button>
            <button onclick="excluirUsuario(${u.id})">Excluir</button>
          </td>
        </tr>
      `;
    });

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" style="color:red;">Erro: ${err.message}</td></tr>`;
  }
}

async function salvarUsuario(e) {
  e.preventDefault();

  const id = document.getElementById('id').value.trim();
  const username = document.getElementById('username').value.trim();
  const nome_completo = document.getElementById('nome_completo').value.trim();
  const email = document.getElementById('email').value.trim();
  const senha = document.getElementById('senha').value;
  const id_colaborador = document.getElementById('id_colaborador').value.trim();
  const operador = document.getElementById('operador').value === 'true';

  if (!username || !nome_completo || !email || (!id && !senha)) {
    alert('Preencha todos os campos obrigatórios. Senha é obrigatória para novo usuário.');
    return;
  }

  const permissoes = {
    operador: operador,
    rnc: { escrita: false, leitura: true, aprovacao: false },
    relatorios: true
  };

  let method = id ? 'PUT' : 'POST';
  let payload = { id, username, nome_completo, email, permissoes };

  if (!id) {
    payload.senha = senha;
  }
  if (id_colaborador) {
    payload.id_colaborador = parseInt(id_colaborador);
  }

  try {
    const res = await fetch(baseURL, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await res.json();

    if (data.success) {
      alert(id ? 'Usuário atualizado com sucesso!' : 'Usuário criado com sucesso!');
      limparFormulario();
      carregarUsuarios();
    } else {
      alert('Erro: ' + data.error);
    }
  } catch (err) {
    alert('Erro ao salvar usuário: ' + err.message);
  }
}

async function editarUsuario(id) {
  try {
    const res = await fetch(`${baseURL}?id=${id}`);
    const data = await res.json();

    if (!data.success) throw new Error(data.error || 'Usuário não encontrado');

    const u = data.data;

    document.getElementById('id').value = u.id;
    document.getElementById('username').value = u.username;
    document.getElementById('nome_completo').value = u.nome_completo;
    document.getElementById('email').value = u.email;
    document.getElementById('senha').value = ''; // senha não mostra
    document.getElementById('id_colaborador').value = u.id_colaborador || '';
    document.getElementById('operador').value = u.permissoes?.operador ? 'true' : 'false';

  } catch (err) {
    alert('Erro ao carregar usuário: ' + err.message);
  }
}

async function excluirUsuario(id) {
  if (!confirm('Confirma a exclusão do usuário?')) return;

  try {
    const res = await fetch(baseURL, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    const data = await res.json();

    if (data.success) {
      alert('Usuário excluído com sucesso!');
      carregarUsuarios();
    } else {
      alert('Erro: ' + data.error);
    }
  } catch (err) {
    alert('Erro ao excluir usuário: ' + err.message);
  }
}

function limparFormulario() {
  document.getElementById('formUsuario').reset();
  document.getElementById('id').value = '';
}
