document.addEventListener('DOMContentLoaded', () => {
    const user = JSON.parse(localStorage.getItem('usuario'));
    if (!user || !user.permissoes.operador) {
        alert('Você não tem permissão para acessar essa tela!');
        window.location.href = 'dashbord.html';
        return;
    }

    listarUsuarios();
    document.getElementById('formUsuario').addEventListener('submit', async (e) => {
        e.preventDefault();
        await salvarUsuario();
    });
});



$(document).ready(function() {
    // Configuração global para tratamento de erros
    window.addEventListener('error', function(e) {
        console.error('Erro não tratado:', e.error);
        alert('Ocorreu um erro inesperado. Verifique o console para detalhes.');
    });

    // Variáveis globais
    let currentData = {};
    let chartStatus, chartSetor, chartTipo, chartPeriodo;
    let tableAnalitico, tablePeriodo;
    
    // Variáveis para os modais
    let modalAnalitico, modalEstatistico, modalPeriodo;
    let chartStatusModal, chartSetorModal, chartTipoModal, chartPeriodoModal;
    let tableAnaliticoModal, tablePeriodoModal;
    
    // Carrega dados iniciais
    buscaStatus();
    buscaSetor();
    initModais();

    // Inicializar modais
    function initModais() {
        modalAnalitico = document.getElementById('modalAnalitico');
        modalEstatistico = document.getElementById('modalEstatistico');
        modalPeriodo = document.getElementById('modalPeriodo');
        
        // Fechar modais ao clicar no X
        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.onclick = function() {
                this.closest('.modal').style.display = 'none';
            };
        });
        
        // Fechar modais ao clicar fora do conteúdo
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        };
    }
    
    // Função para abrir modal
    function openModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    // Aplicar filtros
    $('#aplicarFiltros').click(function() {
        [chartStatus, chartSetor, chartTipo, chartPeriodo].forEach(chart => {
            if (chart) chart.destroy();
        });
    });
    
    // Gerar Relatório Analítico
    $('#gerarAnalitico').click(function() {
        const filtros = getFiltros();
        filtros.tipo_relatorio = 'analitico';
        
        loadShow();
        
        $.get('../controllers/relatorios.php', filtros, function(response) {
            if (!response || !response.success) {
                throw new Error(response?.error || 'Resposta inválida do servidor');
            }
            
            currentData.analitico = response.data;
            renderAnaliticoModal(response.data);
            openModal('modalAnalitico');
        }, 'json')
        .fail(handleAjaxError)
        .always(loadHide);
    });
    
    // Gerar Relatório Estatístico
    $('#gerarEstatistico').click(function() {
        const filtros = getFiltros();
        filtros.tipo_relatorio = 'estatistico';
        
        loadShow();
        
        $.get('../controllers/relatorios.php', filtros, function(response) {
            if (!response || !response.success) {
                throw new Error(response?.error || 'Resposta inválida do servidor');
            }
            
            currentData.estatistico = response.data;
            renderEstatisticoModal(response.data);
            openModal('modalEstatistico');
        }, 'json')
        .fail(handleAjaxError)
        .always(loadHide);
    });
    
    // Gerar Relatório por Período
    $('#gerarPeriodo').click(function() {
        const filtros = getFiltros();
        filtros.tipo_relatorio = 'periodo';
        
        loadShow();
        
        $.get('../controllers/relatorios.php', filtros, function(response) {
            if (!response || !response.success) {
                throw new Error(response?.error || 'Resposta inválida do servidor');
            }
            
            currentData.periodo = response.data;
            renderPeriodoModal(response.data);
            openModal('modalPeriodo');
        }, 'json')
        .fail(handleAjaxError)
        .always(loadHide);
    });
    
    // Exportar PDF
    $('#exportarPDFModal').click(function() {
        if (!currentData.analitico || currentData.analitico.length === 0) {
            alert('Gere o relatório analítico primeiro!');
            return;
        }
        
        try {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            
            doc.text('Relatório Analítico de RNCs', 14, 15);
            let y = 25;
            
            const filtros = getFiltros();
            if (Object.values(filtros).some(Boolean)) {
                doc.text('Filtros aplicados:', 14, y);
                y += 7;
                
                if (filtros.data_inicio && filtros.data_fim) {
                    doc.text(`• Período: ${filtros.data_inicio} a ${filtros.data_fim}`, 20, y);
                    y += 7;
                }
                if (filtros.status) {
                    const statusText = $('#status option:selected').text();
                    doc.text(`• Status: ${statusText}`, 20, y);
                    y += 7;
                }
                if (filtros.setor) {
                    const setorText = $('#setor option:selected').text();
                    doc.text(`• Setor: ${setorText}`, 20, y);
                    y += 7;
                }
                y += 5;
            }
            
            doc.autoTable({
                head: [['ID', 'Data', 'Produto', 'Setor', 'Tipo NC', 'Status', 'Cliente']],
                body: currentData.analitico.map(item => [
                    item.id,
                    formatarData(item.data_abertura),
                    item.produto_nome || '-',
                    item.setor_nome || '-',
                    item.tipo_nc || '-',
                    item.status_desc || '-',
                    item.cliente_nome || '-'
                ]),
                startY: y,
                styles: { fontSize: 8 },
                headStyles: { fillColor: [22, 160, 133] }
            });
            
            doc.save('relatorio_analitico_rnc.pdf');
        } catch (e) {
            console.error('Erro ao gerar PDF:', e);
            alert('Erro ao exportar PDF');
        }
    });
    
    // Exportar Excel
    $('#exportarExcelModal').click(function() {
        if (!currentData.estatistico) {
            alert('Gere o relatório estatístico primeiro!');
            return;
        }
        
        try {
            const wb = XLSX.utils.book_new();
            const data = [
                ['Relatório Estatístico de RNCs'],
                [''],
                ['Total de RNCs', currentData.estatistico.total],
                [''],
                ['Status', 'Quantidade'],
                ...Object.entries(currentData.estatistico.por_status).map(([k, v]) => [k, v]),
                [''],
                ['Setor', 'Quantidade'],
                ...Object.entries(currentData.estatistico.por_setor).map(([k, v]) => [k, v]),
                [''],
                ['Tipo de Não Conformidade', 'Quantidade'],
                ...Object.entries(currentData.estatistico.por_tipo).map(([k, v]) => [k, v])
            ];
            
            const ws = XLSX.utils.aoa_to_sheet(data);
            XLSX.utils.book_append_sheet(wb, ws, "Resumo Estatístico");
            XLSX.writeFile(wb, 'relatorio_estatistico_rnc.xlsx');
        } catch (e) {
            console.error('Erro ao gerar Excel:', e);
            alert('Erro ao exportar Excel');
        }
    });
    
    // Exportar CSV
    $('#exportarCSVModal').click(function() {
        if (!currentData.periodo) {
            alert('Gere o relatório por período primeiro!');
            return;
        }
        
        try {
            let csv = 'Período,Quantidade de RNCs\n';
            csv += Object.entries(currentData.periodo)
                .map(([periodo, qtd]) => `${periodo},${qtd}`)
                .join('\n');
            
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            
            const link = document.createElement('a');
            link.setAttribute('href', url);
            link.setAttribute('download', 'relatorio_periodo_rnc.csv');
            link.style.visibility = 'hidden';
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (e) {
            console.error('Erro ao gerar CSV:', e);
            alert('Erro ao exportar CSV');
        }
    });
    
    // Funções auxiliares
    function getFiltros() {
        return {
            data_inicio: $('#data_inicio').val(),
            data_fim: $('#data_fim').val(),
            status: $('#status').val(),
            setor: $('#setor').val()
        };
    }
    
    function renderAnaliticoModal(data) {
        try {
            if (!Array.isArray(data)) {
                throw new Error('Dados analíticos devem ser um array');
            }
            
            if (tableAnaliticoModal) {
                tableAnaliticoModal.destroy();
            }
            
            tableAnaliticoModal = $('#tabelaAnaliticoModal').DataTable({
                data: data.map(item => [
                    item.id,
                    formatarData(item.data_abertura),
                    item.produto_nome || '-',
                    item.setor_nome || '-',
                    item.tipo_nc || '-',
                    item.status_desc || '-',
                    item.cliente_nome || '-'
                ]),
                columns: [
                    { title: "ID" },
                    { title: "Data" },
                    { title: "Produto" },
                    { title: "Setor" },
                    { title: "Tipo NC" },
                    { title: "Status" },
                    { title: "Cliente" }
                ],
                pageLength: 10,
                language: {
                    url: 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/pt-BR.json'
                },
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
        } catch (e) {
            console.error('Erro ao renderizar tabela:', e);
            $('#tabelaAnaliticoModal').html('<p class="error">Erro ao carregar dados</p>');
        }
    }
    
    function renderEstatisticoModal(data) {
        try {
            if (!data || typeof data !== 'object') {
                throw new Error('Dados estatísticos inválidos');
            }
            
            const estatisticas = {
                total: data.total || 0,
                por_status: data.por_status || {'Nenhum dado': 0},
                por_setor: data.por_setor || {'Nenhum dado': 0},
                por_tipo: data.por_tipo || {'Nenhum dado': 0}
            };
            
            $('#totalRNCsModal').html(`<p><strong>Total de RNCs:</strong> ${estatisticas.total}</p>`);
            
            // Destrói gráficos existentes
            [chartStatusModal, chartSetorModal, chartTipoModal].forEach(chart => {
                if (chart) chart.destroy();
            });
            
            // Cria gráficos
            chartStatusModal = createChart('chartStatusModal', 'RNCs por Status', estatisticas.por_status, 'pie');
            chartSetorModal = createChart('chartSetorModal', 'RNCs por Setor', estatisticas.por_setor, 'bar');
            chartTipoModal = createChart('chartTipoModal', 'RNCs por Tipo', estatisticas.por_tipo, 'doughnut');
            
        } catch (e) {
            console.error('Erro ao renderizar estatísticas:', e);
            $('#totalRNCsModal').html('<p class="error">Erro ao carregar estatísticas</p>');
        }
    }
    
    function renderPeriodoModal(data) {
        try {
            if (!data || typeof data !== 'object') {
                throw new Error('Dados de período inválidos');
            }
            
            // Gráfico de evolução
            if (chartPeriodoModal) chartPeriodoModal.destroy();
            
            const ctx = document.getElementById('chartPeriodoModal');
            if (ctx) {
                chartPeriodoModal = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: Object.keys(data),
                        datasets: [{
                            label: 'Quantidade de RNCs',
                            data: Object.values(data),
                            borderColor: '#e74c3c',
                            backgroundColor: 'rgba(231, 76, 60, 0.1)',
                            fill: true,
                            tension: 0.1
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            title: {
                                display: true,
                                text: 'Evolução de RNCs ao Longo do Tempo'
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }
            
            // Tabela de dados
            if (tablePeriodoModal) tablePeriodoModal.destroy();
            
            tablePeriodoModal = $('#tabelaPeriodoModal').DataTable({
                data: Object.entries(data).map(([periodo, qtd]) => [periodo, qtd]),
                columns: [
                    { title: "Período" },
                    { title: "Quantidade" }
                ],
                pageLength: 10,
                language: {
                    url: 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/pt-BR.json'
                }
            });
            
        } catch (e) {
            console.error('Erro ao renderizar período:', e);
            $('#chartPeriodoModal').parent().html('<p class="error">Erro ao carregar dados de período</p>');
        }
    }
    
    function createChart(elementId, title, data, type) {
        const ctx = document.getElementById(elementId);
        if (!ctx) return null;
        
        const labels = Object.keys(data);
        const values = Object.values(data);
        
        if (labels.length === 0) {
            ctx.parentElement.innerHTML = `<p>Nenhum dado disponível para ${title}</p>`;
            return null;
        }
        
        return new Chart(ctx, {
            type: type,
            data: {
                labels: labels,
                datasets: [{
                    label: title,
                    data: values,
                    backgroundColor: getChartColors(type, labels.length)
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: title
                    }
                }
            }
        });
    }
    
    function getChartColors(type, count) {
        const palettes = {
            pie: ['#e74c3c', '#f39c12', '#2ecc71', '#3498db', '#9b59b6'],
            bar: ['#3498db', '#2980b9', '#1abc9c', '#16a085'],
            doughnut: ['#9b59b6', '#1abc9c', '#34495e', '#e67e22', '#16a085']
        };
        
        return palettes[type]?.slice(0, count) || Array(count).fill('#cccccc');
    }
    
    function formatarData(dataString) {
        if (!dataString) return '-';
        try {
            const date = new Date(dataString);
            return date.toLocaleDateString('pt-BR');
        } catch (e) {
            return dataString;
        }
    }
    
    function loadShow() {
        $('#loader').show();
    }
    
    function loadHide() {
        $('#loader').hide();
    }
    
    function handleAjaxError(jqXHR, textStatus, errorThrown) {
        console.error("Erro na requisição:", textStatus, errorThrown);
        let errorMsg = "Erro ao carregar dados";
        
        if (jqXHR.responseJSON?.error) {
            errorMsg += `: ${jqXHR.responseJSON.error}`;
        } else if (errorThrown) {
            errorMsg += `: ${errorThrown}`;
        }
        
        alert(errorMsg);
    }
});

// Funções para carregar selects
async function buscaStatus() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/status.php');
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const data = await response.json();
        
        if (!Array.isArray(data)) {
            throw new Error('Resposta não é um array');
        }

        const select = document.getElementById('status');
        select.innerHTML = '<option value="">Todos</option>';
        
        data.forEach(status => {
            const option = document.createElement('option');
            option.value = status.id;
            option.textContent = status.descricao;
            select.appendChild(option);
        });

    } catch (error) {
        console.error('Erro ao carregar status:', error);
        document.getElementById('status').innerHTML = '<option value="">Erro ao carregar</option>';
    }
}

async function buscaSetor() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/setor.php');
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const data = await response.json();
        
        if (!Array.isArray(data)) {
            throw new Error('Resposta não é um array');
        }

        const select = document.getElementById('setor');
        select.innerHTML = '<option value="">Todos</option>';
        
        data.forEach(setor => {
            const option = document.createElement('option');
            option.value = setor.id;
            option.textContent = setor.nome;
            select.appendChild(option);
        });

    } catch (error) {
        console.error('Erro ao carregar setores:', error);
        document.getElementById('setor').innerHTML = '<option value="">Erro ao carregar</option>';
    }
}