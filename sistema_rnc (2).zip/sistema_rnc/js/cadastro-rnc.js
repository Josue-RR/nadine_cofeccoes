
function loadShow() {
    const loading = document.getElementById('loading-screen');
    loading.style.display = "flex"
}

function loadHide() {
    const loading = document.getElementById('loading-screen');
    loading.style.display = 'none';
}


document.addEventListener('DOMContentLoaded', function () {
    loadShow();
 
    buscaProduto();
    buscaSetor();
    buscaColaborador();
    buscaTipoNC();
    buscaStatus();
    buscaCliente();
})

document.getElementById('form-cadastro-rnc').addEventListener('submit', function (e) {
    e.preventDefault();


    loadShow();

    const formData = {
        data_abertura: document.getElementById('data_abertura').value,
        descricao: document.getElementById('descricao').value,
        produto: document.getElementById('produto').value,
        setor: document.getElementById('setor').value,
        colaborador: document.getElementById('colaborador').value,
        tipo_nc: document.getElementById('tipo_nc').value,
        status: document.getElementById('status').value,
        cliente: document.getElementById('cliente').value
    }

    fetch('http://localhost/sistema_rnc/controllers/cadastro-rnc.php', {
        method: 'POST',
        headers: {
            'Coneten-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
        .then(response => {
            if (!response.ok) {
                console.log('Erro na requisiçao')
                throw new Error('Erro na Requisição')
            }

            return response.json();
        })
        .then(data => {
            if (data.success) {
                // document.getElementById('mensagem').innerHTML = '<p class="success" >Cliente cadastrado com sucesso</p>';
                document.getElementById('form-cadastro-rnc').reset()
            } else {
                throw new Error(data.error || 'Erro ao cadastrar a RNC')
            }
        })
        .catch(error => {
            // document.getElementById('mensagem').innerHTML = `<p class="error" >Erro: ${error.message}</p>`;
        })
        .finally(() => {
            loadHide();
        })
})





async function buscaStatus() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/status.php');
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            throw new Error(`Resposta não é JSON: ${text}`);
        }

        
        const data = await response.json()
        
        let select = document.getElementById('status');
        
        if (!Array.isArray(data)) {
            throw new Error('Dados recebidos não são um array');
        }

        data.forEach(status => {
            let option = document.createElement('option');
            option.value = status.id
            option.text = status.descricao
            select.appendChild(option)
        });

    } catch (error) {
        console.error('Erro ao carregar status:', error);
    } finally{
        loadHide();
    }
}



async function buscaProduto() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/produto.php');
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            throw new Error(`Resposta não é JSON: ${text}`);
        }

        
        const data = await response.json()
        
        let select = document.getElementById('produto');
        
        if (!Array.isArray(data)) {
            throw new Error('Dados recebidos não são um array');
        }
        
        data.forEach(produto => {
            let option = document.createElement('option');
            option.value = produto.id
            option.text = produto.nome
            select.appendChild(option)
        });

    } catch (error) {
        console.error('Erro ao carregar produto:', error);
    } finally{
        loadHide();
    }
}



async function buscaSetor() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/setor.php');
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            throw new Error(`Resposta não é JSON: ${text}`);
        }

        
        const data = await response.json()
        
        let select = document.getElementById('setor');
        
        if (!Array.isArray(data)) {
            throw new Error('Dados recebidos não são um array');
        }
        
        data.forEach(setor => {
            let option = document.createElement('option');
            option.value = setor.id
            option.text = setor.nome
            select.appendChild(option)
        });

    } catch (error) {
        console.error('Erro ao carregar setor:', error);
    } finally{
        loadHide();
    }
}

async function buscaColaborador() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/colaborador.php');
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            throw new Error(`Resposta não é JSON: ${text}`);
        }

        
        const data = await response.json()
        
        let select = document.getElementById('colaborador');
        
        if (!Array.isArray(data)) {
            throw new Error('Dados recebidos não são um array');
        }
        
        data.forEach(colaborador => {
            let option = document.createElement('option');
            option.value = colaborador.id
            option.text = colaborador.nome
            select.appendChild(option)
        });

    } catch (error) {
        console.error('Erro ao carregar colaborador:', error);
    } finally{
        loadHide();
    }
}


async function buscaTipoNC() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/tipo-nc.php');
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            throw new Error(`Resposta não é JSON: ${text}`);
        }

        
        const data = await response.json()
        
        let select = document.getElementById('tipo_nc');
        
        if (!Array.isArray(data)) {
            throw new Error('Dados recebidos não são um array');
        }
        
        data.forEach(tipo_nc => {
            let option = document.createElement('option');
            option.value = tipo_nc.id
            option.text = tipo_nc.descricao
            select.appendChild(option)
        });

    } catch (error) {
        console.error('Erro ao carregar tipo_nc:', error);
    } finally{
        loadHide();
    }
}


async function buscaCliente() {
    try {
        const response = await fetch('http://localhost/sistema_rnc/controllers/listar-clientes.php');
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            throw new Error(`Resposta não é JSON: ${text}`);
        }

        
        const data = await response.json()
        
        let select = document.getElementById('cliente');
        
        if (!Array.isArray(data)) {
            throw new Error('Dados recebidos não são um array');
        }
        
        data.forEach(cliente => {
            let option = document.createElement('option');
            option.value = cliente.id
            option.text = cliente.nome
            select.appendChild(option)
        });

    } catch (error) {
        console.error('Erro ao carregar cliente:', error);
    } finally{
        loadHide();
    }
}