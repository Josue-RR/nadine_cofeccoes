<?php

session_start();

require '../config/conectaBD.php';

header('Content-Type: application/json');

try {

    $data = json_decode(file_get_contents('php://input'), true);

    $username = $data['username'] ?? '';
    $senha = $data["senha"] ?? '';

    if (empty($username) || empty($senha)) {
        throw new Exception("Usuario e senha são obrigatórios");
    }

    $stmt = $pdo-> prepare("SELECT * FROM autenticar_usuario(:username, :senha)");
    $stmt->execute([':username' => $username, ':senha'=> $senha]);
    
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario){
        throw new Exception('Usuario Invalido');
    }

    $pdo ->prepare('SELECT registrar_login(:id)')->execute([':id' => $usuario['id']]);

    $_SESSION['usuario'] = [
        'id' => $usuario['id'],
        'username' => $usuario['username'],
        'nome' => $usuario['nome_completo'],
        'email' => $usuario['email'],
        'permissoes' => json_decode($usuario['permissoes'], true),
        'id_colaborador' => $usuario['id_colaborador']

    ];

    echo json_encode(['success' => true, 'usuario' => $_SESSION['usuario']]);
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

?>