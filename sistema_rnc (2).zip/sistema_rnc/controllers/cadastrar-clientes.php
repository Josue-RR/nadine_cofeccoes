<?php

header('Content-Type: application/json');

include '../config/conectaBD.php';

try {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (empty($data['nome'])){
        throw new Exception('Nome é Obrigatório');
    }

    $stmt = $pdo->prepare("INSERT INTO cliente (nome, cnpj, email, telefone) VALUES (:nome, :cnpj, :email, :telefone)");

    $success = $stmt->execute([
        ':nome' => $data['nome'],
        ':cnpj' => $data['cnpj'],
        ':email' => $data['email'],
        ':telefone' => $data['telefone']
    ]);

    if ($success) {
        echo json_encode([
            'success' => true,
            'message' => 'Cliente Cadastrado com Sucesso'
        ]);
    } else {
        throw new Error('Falha ao cadastrar o cliente');
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro no banco de dados: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' =>  $e->getMessage() 
    ]);
}



?>