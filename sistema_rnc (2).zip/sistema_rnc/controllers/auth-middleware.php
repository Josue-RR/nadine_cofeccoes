<?php
session_start();

function verificarAutenticacao() {
    if (empty($_SESSION['usuario'])) {
        header('Location: /login.php');
        exit();
    }
}

function verificarPermissao($modulo, $acao) {
    verificarAutenticacao();
    
    $permissoes = $_SESSION['usuario']['permissoes'];
    
    // Se não encontrar o módulo ou a ação específica, nega por padrão
    if (!isset($permissoes[$modulo][$acao])) {
        return false;
    }
    
    return $permissoes[$modulo][$acao];
}

?>