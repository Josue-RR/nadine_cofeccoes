<?php
header('Content-Type: application/json');

// Habilitar erros para depuração
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../config/conectaBD.php';

// Verificar se a conexão foi estabelecida
if (!isset($pdo)) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão com o banco de dados']);
    exit;
}

try {
    // Obter filtros com valores padrão seguros
    $filtros = [
        'data_inicio' => $_GET['data_inicio'] ?? null,
        'data_fim' => $_GET['data_fim'] ?? null,
        'status' => $_GET['status'] ?? null,
        'setor' => $_GET['setor'] ?? null,
        'tipo_relatorio' => $_GET['tipo_relatorio'] ?? 'analitico'
    ];

    // Construir query base com proteção contra valores nulos
    $query = "SELECT 
                r.id, 
                r.data_abertura, 
                COALESCE(s.descricao, 'Não informado') as status_desc, 
                COALESCE(st.nome, 'Não informado') as setor_nome, 
                COALESCE(p.nome, 'Não informado') as produto_nome, 
                COALESCE(c.nome, 'Não informado') as cliente_nome, 
                COALESCE(t.descricao, 'Não informado') as tipo_nc
              FROM rnc r
              LEFT JOIN status_rnc s ON r.id_status = s.id
              LEFT JOIN setor st ON r.id_setor = st.id
              LEFT JOIN produto p ON r.id_produto = p.id
              LEFT JOIN cliente c ON r.id_cliente = c.id
              LEFT JOIN tipo_nao_conformidade t ON r.id_tipo_nc = t.id
              WHERE 1=1";

    $params = [];

    // Aplicar filtros de forma segura
    if ($filtros['data_inicio'] && $filtros['data_fim']) {
        $query .= " AND r.data_abertura BETWEEN :data_inicio AND :data_fim";
        $params[':data_inicio'] = $filtros['data_inicio'];
        $params[':data_fim'] = $filtros['data_fim'];
    }

    if ($filtros['status']) {
        $query .= " AND r.id_status = :status";
        $params[':status'] = (int)$filtros['status'];
    }

    if ($filtros['setor']) {
        $query .= " AND r.id_setor = :setor";
        $params[':setor'] = (int)$filtros['setor'];
    }

    // Executar consulta
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $rncs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Processar para diferentes tipos de relatório
    switch ($filtros['tipo_relatorio']) {
        case 'analitico':
            $response = [
                'success' => true,
                'data' => $rncs ?: [],
                'total' => count($rncs)
            ];
            break;
            
        case 'estatistico':
            $estatisticas = [
                'total' => count($rncs),
                'por_status' => [],
                'por_setor' => [],
                'por_tipo' => []
            ];
            
            foreach ($rncs as $rnc) {
                // Garante que nenhum valor seja nulo
                $status = $rnc['status_desc'] ?? 'Não informado';
                $setor = $rnc['setor_nome'] ?? 'Não informado';
                $tipo = $rnc['tipo_nc'] ?? 'Não informado';
                
                $estatisticas['por_status'][$status] = ($estatisticas['por_status'][$status] ?? 0) + 1;
                $estatisticas['por_setor'][$setor] = ($estatisticas['por_setor'][$setor] ?? 0) + 1;
                $estatisticas['por_tipo'][$tipo] = ($estatisticas['por_tipo'][$tipo] ?? 0) + 1;
            }
            
            // Garante que os arrays existam mesmo quando vazios
            $response = [
                'success' => true,
                'data' => [
                    'total' => $estatisticas['total'],
                    'por_status' => $estatisticas['por_status'] ?: ['Nenhum dado' => 0],
                    'por_setor' => $estatisticas['por_setor'] ?: ['Nenhum dado' => 0],
                    'por_tipo' => $estatisticas['por_tipo'] ?: ['Nenhum dado' => 0]
                ]
            ];
            break;
            
        case 'periodo':
            $evolucao = [];
            foreach ($rncs as $rnc) {
                $mes_ano = date('m/Y', strtotime($rnc['data_abertura']));
                $evolucao[$mes_ano] = ($evolucao[$mes_ano] ?? 0) + 1;
            }
            ksort($evolucao);
            
            $response = [
                'success' => true,
                'data' => $evolucao ?: ['Nenhum dado' => 0]
            ];
            break;
            
        default:
            $response = [
                'success' => false,
                'error' => 'Tipo de relatório inválido'
            ];
    }

    echo json_encode($response);

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Erro no banco de dados',
        'details' => $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Erro no servidor',
        'details' => $e->getMessage()
    ]);
}