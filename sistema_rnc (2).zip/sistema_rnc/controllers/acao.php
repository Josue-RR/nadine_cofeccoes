<?php
header('Content-Type: application/json');
require_once '../config/conectaBD.php';

try {
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        $stmt = $pdo->query("SELECT * FROM vw_acoes_corretivas_recentes");
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);

    if ($method === 'POST') {
        $stmt = $pdo->prepare("INSERT INTO acao_corretiva (id_rnc, descricao, data_execucao, id_responsavel) VALUES (:id_rnc, :descricao, :data_execucao, :id_responsavel)");
        $stmt->execute([
         ':id_rnc' => $input['id_rnc'],
         ':descricao' => $input['descricao'],
         ':data_execucao' => $input['data_execucao'],
         ':id_responsavel' => $input['id_responsavel']
        ]);

        $sqlUpdateStatus = "UPDATE rnc SET id_status = 14 WHERE id = :rnc_id";
        $stmtUpdate = $pdo->prepare($sqlUpdateStatus);
        $stmtUpdate->execute([':rnc_id' => $input['id_rnc']]);

        echo json_encode(['success' => true]);
        exit;
    }

    if ($method === 'PUT') {
        $campo = $input['campo'];
        $valor = $input['valor'];
        $id = intval($input['id']);

        $allowedFields = ['descricao', 'data_execucao', 'responsavel'];
        if (!in_array($campo, $allowedFields)) {
            throw new Exception('Campo inválido');
        }

        $sql = "UPDATE acao_corretiva SET $campo = :valor WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':valor' => $valor, ':id' => $id]);
        echo json_encode(['success' => true]);
        exit;
    }

    if ($method === 'DELETE') {
        $id = intval($input['id']);
        $stmt = $pdo->prepare("DELETE FROM acao_corretiva WHERE id = :id");
        $stmt->execute([':id' => $id]);
        echo json_encode(['success' => true]);
        exit;
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
