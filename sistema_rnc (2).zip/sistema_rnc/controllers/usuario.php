<?php
header('Content-Type: application/json');
require_once '../config/conectaBD.php';

try {
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $pdo->prepare("SELECT * FROM usuario WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$usuario) {
                echo json_encode(['success' => false, 'error' => 'Usuário não encontrado']);
                exit;
            }
            $usuario['permissoes'] = json_decode($usuario['permissoes'], true);
            echo json_encode(['success' => true, 'data' => $usuario]);
            exit;
        }

        $stmt = $pdo->query("SELECT * FROM usuario ORDER BY id");
        $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($usuarios as &$u) {
            $u['permissoes'] = json_decode($u['permissoes'], true);
        }
        echo json_encode(['success' => true, 'data' => $usuarios]);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);

    if ($method === 'POST') {
        $username = $input['username'] ?? '';
        $nome_completo = $input['nome_completo'] ?? '';
        $email = $input['email'] ?? '';
        $senha = $input['senha'] ?? '';
        $permissoes = $input['permissoes'] ?? [];
        $id_colaborador = $input['id_colaborador'] ?? null;

        if (!$username || !$nome_completo || !$email || !$senha) {
            throw new Exception('Campos obrigatórios faltando');
        }

        $senha_hash = md5($senha);

        $stmt = $pdo->prepare("INSERT INTO usuario (username, nome_completo, email, senha_hash, permissoes, id_colaborador) VALUES (:username, :nome, :email, :senha, :permissoes, :id_colaborador)");
        $stmt->execute([
            ':username' => $username,
            ':nome' => $nome_completo,
            ':email' => $email,
            ':senha' => $senha_hash,
            ':permissoes' => json_encode($permissoes),
            ':id_colaborador' => $id_colaborador
        ]);
        echo json_encode(['success' => true]);
        exit;
    }

    if ($method === 'PUT') {
        $id = intval($input['id']);
        $username = $input['username'] ?? '';
        $nome_completo = $input['nome_completo'] ?? '';
        $email = $input['email'] ?? '';
        $permissoes = $input['permissoes'] ?? [];
        $id_colaborador = $input['id_colaborador'] ?? null;

        if (!$id || !$username || !$nome_completo || !$email) {
            throw new Exception('Campos obrigatórios faltando');
        }

        // Atualiza sem alterar senha
        $stmt = $pdo->prepare("UPDATE usuario SET username = :username, nome_completo = :nome, email = :email, permissoes = :permissoes, id_colaborador = :id_colaborador WHERE id = :id");
        $stmt->execute([
            ':username' => $username,
            ':nome' => $nome_completo,
            ':email' => $email,
            ':permissoes' => json_encode($permissoes),
            ':id_colaborador' => $id_colaborador,
            ':id' => $id
        ]);

        echo json_encode(['success' => true]);
        exit;
    }

    if ($method === 'DELETE') {
        $id = intval($input['id']);
        if (!$id) {
            throw new Exception('ID inválido para exclusão');
        }

        $stmt = $pdo->prepare("DELETE FROM usuario WHERE id = :id");
        $stmt->execute([':id' => $id]);
        echo json_encode(['success' => true]);
        exit;
    }

    throw new Exception('Método não suportado');
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
