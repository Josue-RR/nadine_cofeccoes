<?php
header('Content-Type: application/json');
require_once '../config/conectaBD.php';

try {
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        $filtro = $_GET['filtro'] ?? null;
        $sql = "SELECT * FROM vw_rncs_completas";
        if ($filtro) {
            $sql .= " WHERE status_id = " . intval($filtro);
        }
        $sql .= " ORDER BY data_abertura DESC";
        $stmt = $pdo->query($sql);
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        exit;
    }

    if ($method === 'PUT') {
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id']);
        $status = intval($input['status']);

        $sql = "UPDATE rnc SET id_status = :status WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':status' => $status, ':id' => $id]);
        echo json_encode(['success' => true]);
        exit;
    }

    if ($method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';

        if ($action === 'editar') {
            $id = intval($input['id']);
            $descricao = $input['descricao'];
            $status = intval($input['status']);

            $sql = "UPDATE rnc SET descricao = :descricao, id_status = :status WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':descricao' => $descricao,
                ':status' => $status,
                ':id' => $id
            ]);

            echo json_encode(['success' => true]);
            exit;
        }

        if ($action === 'excluir') {
            $id = intval($input['id']);
            $stmt = $pdo->prepare("DELETE FROM rnc WHERE id = :id");
            $stmt->execute([':id' => $id]);
            echo json_encode(['success' => true]);
            exit;
        }
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
