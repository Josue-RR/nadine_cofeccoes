<?php

header('Content-Type: application/json');

include('../config/conectaBD.php');

try {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    $stmt = $pdo->prepare("CALL sp_abrir_rnc(
        :data_abertura,
        :descricao,
        :produto,
        :setor,
        :colaborador,
        :tipo_nc,
        :status,
        :cliente
    )");

    $success = $stmt->execute([
        ':data_abertura' => $data['data_abertura'] ?? date('Y-m-d'),
        ':descricao' => $data['descricao'],
        ':produto' => $data['produto'],
        ':setor' => $data['setor'] ?? null,
        ':colaborador' => $data['colaborador'] ?? null,
        ':tipo_nc' => $data['tipo_nc'] ?? null,
        ':status' => $data['status'] ?? 1, // Status padrão (1 = Aberto)
        ':cliente' => $data['cliente'] ?? null
    ]);

    echo json_encode(['success' => true, 'message' => 'RNC aberta com sucesso']);

}catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Erro no banco: ' . $e->getMessage()]);
} catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}   


?>