<?php

header('Content-Type: application/json');

try {
    include '../config/conectaBD.php';
    
    $stmt = $pdo->query("SELECT * FROM tipo_nao_conformidade");
    if ($stmt === false) {
        throw new Exception('Falha na busca do tipo_nc');
    }
    
    $tipo_nc = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($tipo_nc)) {
        echo json_encode(['message' => 'Nenhum tipo_nc  Cadastrado!']);
    } else {
        echo json_encode($tipo_nc);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro no Banco de Dados: ' . $e->getMessage()]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

?>