<?php
header('Content-Type: application/json');

try {
    include '../config/conectaBD.php';
    
    $stmt = $pdo->query("SELECT * FROM cliente");
    if ($stmt === false) {
        throw new Exception('Falha na pesquisa de cliente');
    }
    
    $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($clientes)) {
        echo json_encode(['message' => 'Nenhum Cliente Cadastrado!']);
    } else {
        echo json_encode($clientes);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro no Banco de Dados: ' . $e->getMessage()]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>  